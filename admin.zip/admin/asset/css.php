<link rel="shortcut icon" href="../vendor/assets/logo.jpg">
<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome Icons -->
<link rel="stylesheet" href="../vendor/assets/plugins/fontawesome-free/css/all.min.css">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="../vendor/assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="../vendor/assets/dist/css/adminlte.min.css">
<link rel="stylesheet" href="../vendor/assets/plugins/select2/css/select2.min.css">

<!-- table  -->
<!-- DataTables -->
<link rel="stylesheet" href="../vendor/assets/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="../vendor/assets/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="../vendor/assets/datatables-buttons/css/buttons.bootstrap4.min.css">
