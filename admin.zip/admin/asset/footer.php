<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
  <strong>Developed with Love by <a href="https://digisoft.id">Nur Okatvia</a>.</strong>
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0 Lechy
  </div>
</footer>
